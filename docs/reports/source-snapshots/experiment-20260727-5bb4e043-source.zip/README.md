# 弱信号覆盖下新能源场站虚拟电厂项目

## 项目简介

本项目面向“中国西北边疆新能源基地 + 虚拟电厂数字控制网络”比赛演示场景，构建一个可运行、可验证、可离线兜底的虚拟电厂监控与故障注入平台。系统覆盖光伏、风电、储能、市电接口、可控负荷和充电设施，通过模拟器生成遥测，经 MQTT 进入后端，再写入 Redis 与 PostgreSQL，最终由 REST API 驱动前端驾驶舱、故障注入实验台和实验结果对比页面。

## 技术栈

- 前端：Vue 3、TypeScript、Pinia、Vue Router、Element Plus、ECharts、Vite。
- 后端：Java 21、Spring Boot 3.5、Spring Web、Validation、Data JPA、Data Redis、Actuator。
- 模拟器：Java 21、Paho MQTT v5。
- 基础设施：Docker Compose、EMQX、PostgreSQL、Redis。

## 系统架构

```mermaid
flowchart LR
  Simulator["Java 模拟器"] -->|"MQTT v5 QoS1"| EMQX["EMQX"]
  EMQX --> Backend["Spring Boot 后端"]
  Backend --> Redis["Redis 最新状态"]
  Backend --> PostgreSQL["PostgreSQL 历史数据"]
  Frontend["Vue 前端 API 模式"] -->|"REST API"| Backend
  Frontend -.->|"mock 模式"| Mock["本地 Mock 数据"]
```

## 数据链路

1. simulator 生成六类场站遥测和心跳。
2. simulator 发布到 `vpp/{stationId}/telemetry/report`、`vpp/{stationId}/heartbeat/report`。
3. backend 订阅 MQTT，校验消息、判断 S0-S4 链路状态并落库。
4. Redis 保存 `vpp:station:{stationId}:latest`、`vpp:station:{stationId}:heartbeat` 等实时状态。
5. PostgreSQL 保存 `telemetry_history`、`telemetry_snapshot`、`fault_event`、`experiment_run` 等历史数据。
6. frontend api 模式通过 REST API 展示总览、故障实验、结果对比和回放分析。

## 目录结构

- `frontend`：Vue 3 前端，支持 `mock` 与 `api` 双数据源。
- `backend`：Spring Boot 云侧平台，负责 REST、MQTT 入站、Redis、PostgreSQL。
- `simulator`：独立 Java 场站模拟器，负责 MQTT 遥测、心跳和实验故障行为。
- `scripts`：Windows PowerShell 启停和运行时检查脚本。
- `docs/contracts`：REST/MQTT/Redis/数据库契约文档。
- `docs/demo`：比赛演示脚本。
- `docs/runbook`：排障清单。
- `docs/defense`：答辩提纲和讲解稿。
- `docs/delivery`：最终交付检查清单。

## 环境要求

- JDK 21，建议设置 `JAVA21_HOME` 或 `JDK21_HOME`。
- Maven 3.9+，当前项目可使用 `mvn.cmd -s maven-settings.xml`。
- Node.js 与 npm。
- Docker Desktop，需启用 Linux Engine。
- Windows PowerShell。

## `.env` 配置说明

基于 `.env.example` 创建本地 `.env`。`.env` 只保存在本机，不要提交真实密码。

- `POSTGRES_DB`、`POSTGRES_USER`、`POSTGRES_PASSWORD`：PostgreSQL 数据库配置。
- `REDIS_PASSWORD`：Redis 访问密码。
- `EMQX_DASHBOARD_USERNAME`、`EMQX_DASHBOARD_PASSWORD`：EMQX Dashboard 初始化登录信息。
- `EMQX_USERNAME`、`EMQX_PASSWORD`：MQTT 客户端账号。
- `BACKEND_SERVER_PORT`、`BACKEND_ALLOWED_ORIGIN`：后端端口和 CORS 来源。
- `MQTT_HOST`、`MQTT_PORT`：MQTT Broker 地址。
- `SIMULATION_INTERVAL_MS`、`SIMULATION_RANDOM_SEED`、`SIMULATION_INITIAL_SCENARIO`、`SIMULATION_STATION_IDS`：模拟器运行参数。
- `VPP_AI_ENABLED`：多智能体模型调用总开关，默认 `false`，关闭时完整使用规则模式。
- `DEEPSEEK_ENABLED`、`DEEPSEEK_BASE_URL`、`DEEPSEEK_API_KEY`、`DEEPSEEK_MODEL`、`DEEPSEEK_TIMEOUT_SECONDS`：DeepSeek OpenAI 兼容配置，默认模型为 `deepseek-v4-flash`。

模型 URL、模型名和 API Key 均由本地环境变量提供。真实密钥不得写入 `.env.example`、源码、日志或文档。

## 一键启动

小白推荐方式：直接双击根目录的 `quick-start.cmd`。

它会自动完成：

- 如果缺少 `.env`，自动从 `.env.example` 创建。
- 检查 Docker、Node.js、npm。
- 首次启动时安装前端依赖。
- 启动 PostgreSQL、Redis、EMQX、后端、模拟器和前端页面。
- 自动打开前端访问地址。

命令行方式：

```powershell
Set-Location C:\Users\80644\Documents\弱信号
.\quick-start.cmd
```

启动后访问：

- 前端：`http://127.0.0.1:4173/`
- 后端健康检查：`http://127.0.0.1:8080/api/v1/health`
- EMQX Dashboard：`http://127.0.0.1:18083/`

停止：

```powershell
Set-Location C:\Users\80644\Documents\弱信号
.\scripts\stop-all.ps1
```

`stop-all.ps1` 默认不删除 Docker volume，历史数据仍保留。

## 手动启动

```powershell
Set-Location C:\Users\80644\Documents\弱信号
.\scripts\start-infrastructure.ps1
docker compose -p weak-signal ps
```

```powershell
Set-Location C:\Users\80644\Documents\弱信号
.\scripts\start-backend.ps1
```

```powershell
Set-Location C:\Users\80644\Documents\弱信号
.\scripts\start-simulator.ps1
```

```powershell
Set-Location C:\Users\80644\Documents\弱信号\frontend
$env:VITE_DATA_SOURCE='api'
$env:VITE_API_BASE_URL='http://127.0.0.1:8080'
npm run build
npm run preview -- --host 127.0.0.1 --port 4173
```

## 常用验证命令

```powershell
.\scripts\verify-runtime.ps1
Invoke-RestMethod -Uri http://127.0.0.1:8080/api/v1/health
Invoke-RestMethod -Uri http://127.0.0.1:8080/api/v1/stations
Invoke-RestMethod -Uri http://127.0.0.1:8080/api/v1/dashboard/summary
docker exec weak-signal-emqx emqx ctl clients list
```

## 前端 mock/api 模式

- mock 模式：`VITE_DATA_SOURCE=mock`，不依赖后端和基础设施，适合作为比赛兜底演示。
- api 模式：`VITE_DATA_SOURCE=api`，通过 `VITE_API_BASE_URL` 访问真实后端。

## 常见问题入口

排障清单见 [docs/runbook/troubleshooting.md](docs/runbook/troubleshooting.md)。
