package com.weaksignal.vpp.backend.api.dto;

/**
 * 调度计划创建请求。
 *
 * @param dispatchContextSnapshotId 调度上下文快照标识
 * @param conservativePlan 是否生成保守计划
 */
public record DispatchPlanCreateRequest(
        String dispatchContextSnapshotId,
        boolean conservativePlan
) {
}
