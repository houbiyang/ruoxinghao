package com.weaksignal.vpp.backend.application;

import com.weaksignal.vpp.backend.api.ApiException;
import com.weaksignal.vpp.backend.api.dto.DashboardSummaryResponse;
import com.weaksignal.vpp.backend.api.dto.EventResponse;
import com.weaksignal.vpp.backend.api.dto.PowerTrendPointResponse;
import com.weaksignal.vpp.backend.api.dto.ResourceControlActionResponse;
import com.weaksignal.vpp.backend.api.dto.ResourceDeviceStatusResponse;
import com.weaksignal.vpp.backend.api.dto.ResourceMetricResponse;
import com.weaksignal.vpp.backend.api.dto.ResourceQualityPointResponse;
import com.weaksignal.vpp.backend.api.dto.ResourceTelemetryPointResponse;
import com.weaksignal.vpp.backend.api.dto.ScenePositionResponse;
import com.weaksignal.vpp.backend.api.dto.StationDetailResponse;
import com.weaksignal.vpp.backend.api.dto.StationStateResponse;
import com.weaksignal.vpp.backend.domain.DemoScenario;
import com.weaksignal.vpp.backend.domain.ResourceType;
import com.weaksignal.vpp.backend.infrastructure.persistence.entity.FaultEventEntity;
import com.weaksignal.vpp.backend.infrastructure.persistence.entity.ResourceDeviceEntity;
import com.weaksignal.vpp.backend.infrastructure.persistence.entity.StationEntity;
import com.weaksignal.vpp.backend.infrastructure.persistence.entity.TelemetryHistoryEntity;
import com.weaksignal.vpp.backend.infrastructure.persistence.entity.TelemetrySnapshotEntity;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.FaultEventRepository;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.ResourceDeviceRepository;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.StationRepository;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.TelemetryHistoryRepository;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.TelemetrySnapshotRepository;
import com.weaksignal.vpp.backend.infrastructure.redis.RedisRealtimeStateStore;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/**
 * 总览与场站查询服务。
 */
@Service
public class DashboardQueryService {

    private static final DateTimeFormatter LABEL_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");

    private final StationRepository stationRepository;
    private final TelemetrySnapshotRepository telemetrySnapshotRepository;
    private final TelemetryHistoryRepository telemetryHistoryRepository;
    private final ResourceDeviceRepository resourceDeviceRepository;
    private final FaultEventRepository faultEventRepository;
    private final StationLayoutRegistry stationLayoutRegistry;
    private final RedisRealtimeStateStore redisRealtimeStateStore;
    private final Clock clock;

    /**
     * 注入查询依赖。
     */
    public DashboardQueryService(
            StationRepository stationRepository,
            TelemetrySnapshotRepository telemetrySnapshotRepository,
            TelemetryHistoryRepository telemetryHistoryRepository,
            ResourceDeviceRepository resourceDeviceRepository,
            FaultEventRepository faultEventRepository,
            StationLayoutRegistry stationLayoutRegistry,
            RedisRealtimeStateStore redisRealtimeStateStore,
            Clock clock
    ) {
        this.stationRepository = stationRepository;
        this.telemetrySnapshotRepository = telemetrySnapshotRepository;
        this.telemetryHistoryRepository = telemetryHistoryRepository;
        this.resourceDeviceRepository = resourceDeviceRepository;
        this.faultEventRepository = faultEventRepository;
        this.stationLayoutRegistry = stationLayoutRegistry;
        this.redisRealtimeStateStore = redisRealtimeStateStore;
        this.clock = clock;
    }

    /**
     * 查询场站列表。
     *
     * @return 场站列表
     */
    public List<StationStateResponse> getStations() {
        List<StationEntity> stations = stationRepository.findAll();
        List<StationStateResponse> responses = new ArrayList<>();
        for (StationEntity station : stations) {
            TelemetrySnapshotEntity snapshot = telemetrySnapshotRepository.findByStationId(station.getStationId()).orElse(null);
            responses.add(toStationState(station, snapshot));
        }
        return responses;
    }

    /**
     * 查询场站详情。
     *
     * @param stationId 场站标识
     * @return 场站详情
     */
    public StationDetailResponse getStationDetail(String stationId) {
        StationEntity station = stationRepository.findByStationId(stationId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "STATION_NOT_FOUND", "场站不存在", java.util.Map.of("stationId", stationId)));
        TelemetrySnapshotEntity snapshot = telemetrySnapshotRepository.findByStationId(stationId).orElse(null);
        List<ResourceDeviceEntity> devices = resourceDeviceRepository.findByStationId(stationId);
        List<TelemetryHistoryEntity> history = telemetryHistoryRepository.findByStationIdOrderByReceivedTimestampDesc(stationId, PageRequest.of(0, 8));
        List<FaultEventEntity> events = faultEventRepository.findAllByOrderByOccurredAtDesc(PageRequest.of(0, 6)).stream()
                .filter(event -> stationId.equals(event.getStationId()))
                .limit(4)
                .toList();

        List<ResourceMetricResponse> metrics = buildMetrics(station, snapshot);
        List<ResourceDeviceStatusResponse> deviceStatuses = devices.stream()
                .map(device -> new ResourceDeviceStatusResponse(
                        device.getDeviceId(),
                        device.getDeviceName(),
                        mapDeviceStatus(device.getStatus()),
                        snapshot == null ? "--" : String.format("%.1f kW", snapshot.getActivePower()),
                        "当前设备参与 " + station.getStationName() + " 功率调节。"
                ))
                .toList();

        List<ResourceControlActionResponse> controlActions = List.of(
                new ResourceControlActionResponse(stationId + "-action-01", "功率下发", "可执行", "用于比赛演示的场景切换和功率约束动作。"),
                new ResourceControlActionResponse(stationId + "-action-02", "链路诊断", "可执行", "触发场站通信质量复核。"),
                new ResourceControlActionResponse(stationId + "-action-03", "本地保守模式", stationId.equals("grid-link-00") ? "已锁定" : "可执行", "弱信号失联时进入本地自治兜底策略。")
        );

        List<ResourceTelemetryPointResponse> powerTrend = history.stream()
                .sorted((left, right) -> left.getReceivedTimestamp().compareTo(right.getReceivedTimestamp()))
                .map(item -> new ResourceTelemetryPointResponse(
                        LABEL_FORMATTER.format(item.getReceivedTimestamp()),
                        item.getActivePower(),
                        Math.max(item.getActivePower(), item.getAvailableCapacity() * 0.88)
                ))
                .toList();

        List<ResourceQualityPointResponse> qualityTrend = history.stream()
                .sorted((left, right) -> left.getReceivedTimestamp().compareTo(right.getReceivedTimestamp()))
                .map(item -> new ResourceQualityPointResponse(
                        LABEL_FORMATTER.format(item.getReceivedTimestamp()),
                        item.getLatency(),
                        item.getPacketLossRate()
                ))
                .toList();

        return new StationDetailResponse(
                stationId,
                buildOverviewText(station, snapshot),
                metrics,
                deviceStatuses,
                controlActions,
                powerTrend,
                qualityTrend,
                events.stream().map(this::toEventResponse).toList()
        );
    }

    /**
     * 查询总览摘要。
     *
     * @return 摘要信息
     */
    public DashboardSummaryResponse getDashboardSummary() {
        List<StationStateResponse> stations = getStations();
        double totalOutputPower = stations.stream().mapToDouble(StationStateResponse::activePower).sum();
        double adjustableCapacity = stations.stream()
                .filter(StationStateResponse::online)
                .mapToDouble(station -> Math.max(0, station.availableCapacity() - station.activePower()))
                .sum();
        int onlineStationCount = (int) stations.stream().filter(StationStateResponse::online).count();
        int alarmCount = (int) faultEventRepository.findAllByOrderByOccurredAtDesc(PageRequest.of(0, 20)).stream()
                .filter(event -> !"提示".equals(event.getLevel()))
                .count();
        DemoScenario activeScenario = redisRealtimeStateStore.getActiveScenario().orElse(DemoScenario.STABLE);

        return new DashboardSummaryResponse(
                totalOutputPower,
                adjustableCapacity,
                onlineStationCount,
                alarmCount,
                activeScenario.getControlMode(),
                activeScenario
        );
    }

    /**
     * 查询功率趋势。
     *
     * @param from 起始时间
     * @param to 截止时间
     * @param limit 限制数量
     * @return 趋势点
     */
    public List<PowerTrendPointResponse> getPowerTrend(OffsetDateTime from, OffsetDateTime to, int limit) {
        List<TelemetryHistoryEntity> history = telemetryHistoryRepository.findByReceivedTimestampBetweenOrderByReceivedTimestampAsc(
                from,
                to,
                PageRequest.of(0, limit)
        );
        return history.stream()
                .map(item -> new PowerTrendPointResponse(
                        LABEL_FORMATTER.format(item.getReceivedTimestamp()),
                        Math.max(item.getActivePower(), item.getAvailableCapacity() * 0.9),
                        item.getActivePower()
                ))
                .toList();
    }

    /**
     * 查询最近事件。
     *
     * @param limit 条数
     * @return 最近事件
     */
    public List<EventResponse> getLatestEvents(int limit) {
        return faultEventRepository.findAllByOrderByOccurredAtDesc(PageRequest.of(0, limit)).stream()
                .map(this::toEventResponse)
                .toList();
    }

    private StationStateResponse toStationState(StationEntity station, TelemetrySnapshotEntity snapshot) {
        if (snapshot == null) {
            return new StationStateResponse(
                    station.getStationId(),
                    station.getStationName(),
                    station.getResourceType(),
                    0,
                    0,
                    com.weaksignal.vpp.backend.domain.LinkState.S3,
                    0,
                    100,
                    0,
                    false,
                    new ScenePositionResponse(
                            stationLayoutRegistry.getPosition(station.getStationId()).x(),
                            stationLayoutRegistry.getPosition(station.getStationId()).y()
                    ),
                    0,
                    null,
                    null
            );
        }

        return new StationStateResponse(
                station.getStationId(),
                station.getStationName(),
                station.getResourceType(),
                snapshot.getActivePower(),
                snapshot.getAvailableCapacity(),
                snapshot.getLinkState(),
                snapshot.getLatency(),
                snapshot.getPacketLossRate(),
                snapshot.getDataAge(),
                snapshot.isOnline(),
                new ScenePositionResponse(
                        stationLayoutRegistry.getPosition(station.getStationId()).x(),
                        stationLayoutRegistry.getPosition(station.getStationId()).y()
                ),
                snapshot.getReceivedTimestamp() == null
                        ? snapshot.getDataAge()
                        : Math.max(0, java.time.Duration.between(snapshot.getReceivedTimestamp(), OffsetDateTime.now(clock)).toSeconds()),
                snapshot.getActiveFaultCode(),
                snapshot.getReceivedTimestamp()
        );
    }

    private List<ResourceMetricResponse> buildMetrics(StationEntity station, TelemetrySnapshotEntity snapshot) {
        if (snapshot == null) {
            return List.of(
                    new ResourceMetricResponse("在线状态", "离线", ""),
                    new ResourceMetricResponse("最近功率", 0, "kW"),
                    new ResourceMetricResponse("链路状态", "S3", "")
            );
        }

        List<ResourceMetricResponse> metrics = new ArrayList<>();
        metrics.add(new ResourceMetricResponse(powerMetricLabel(station.getResourceType(), snapshot.getActivePower()), Math.abs(snapshot.getActivePower()), "kW"));
        metrics.add(new ResourceMetricResponse("可用容量", snapshot.getAvailableCapacity(), "kW"));
        metrics.add(new ResourceMetricResponse("通信时延", snapshot.getLatency(), "ms"));
        metrics.add(new ResourceMetricResponse("丢包率", snapshot.getPacketLossRate(), "%"));
        metrics.add(new ResourceMetricResponse("数据时效", snapshot.getDataAge(), "s"));
        metrics.add(new ResourceMetricResponse("链路状态", snapshot.getLinkState().name(), ""));
        if (station.getResourceType() == ResourceType.STORAGE) {
            metrics.add(new ResourceMetricResponse("调节特性", "双向功率爬坡受控", ""));
        }
        if (station.getResourceType() == ResourceType.PHOTOVOLTAIC) {
            metrics.add(new ResourceMetricResponse("出力特性", "受日照平滑波动影响", ""));
        }
        return metrics;
    }

    /**
     * 返回资源功率指标名称。
     *
     * @param resourceType 资源类型
     * @param activePower 实时有功功率
     * @return 功率指标名称
     */
    private String powerMetricLabel(ResourceType resourceType, double activePower) {
        return switch (resourceType) {
            case PHOTOVOLTAIC, WIND, THERMAL -> "发电功率";
            case GRID -> activePower >= 0 ? "市电购电" : "市电上网";
            case STORAGE -> activePower >= 0 ? "储能放电" : "储能充电";
            case CHARGING -> "充电功率";
            case LOAD -> "用电功率";
        };
    }

    private String buildOverviewText(StationEntity station, TelemetrySnapshotEntity snapshot) {
        if (snapshot == null) {
            return station.getStationName() + " 当前尚未收到实时遥测，前端将显示离线占位信息。";
        }
        return station.getStationName() + " 当前功率为 " + String.format("%.1f", snapshot.getActivePower())
                + "kW，链路状态 " + snapshot.getLinkState().name()
                + "，通信时延 " + snapshot.getLatency() + "ms。";
    }

    private String mapDeviceStatus(String status) {
        return switch (status) {
            case "RUNNING" -> "运行";
            case "STANDBY" -> "待机";
            case "ALARM" -> "告警";
            default -> "离线";
        };
    }

    private EventResponse toEventResponse(FaultEventEntity event) {
        return new EventResponse(
                event.getEventId(),
                event.getTitle(),
                event.getDescription(),
                event.getLevel(),
                event.getOccurredAt().format(DateTimeFormatter.ofPattern("HH:mm:ss")),
                event.getStationId()
        );
    }
}
