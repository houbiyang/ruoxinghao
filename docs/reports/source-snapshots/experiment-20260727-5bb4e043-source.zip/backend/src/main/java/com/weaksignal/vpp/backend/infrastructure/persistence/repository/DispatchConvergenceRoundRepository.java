package com.weaksignal.vpp.backend.infrastructure.persistence.repository;

import com.weaksignal.vpp.backend.infrastructure.persistence.entity.DispatchConvergenceRoundEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 调度收敛轮次审计仓储。
 */
public interface DispatchConvergenceRoundRepository extends JpaRepository<DispatchConvergenceRoundEntity, Long> {

    Optional<DispatchConvergenceRoundEntity> findByExperimentRunIdAndRoundNumber(String experimentRunId, int roundNumber);
}
