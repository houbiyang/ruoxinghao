package com.weaksignal.vpp.backend.marketdispatch;

import com.weaksignal.vpp.backend.planning.DispatchContextSnapshot;

/**
 * 优化输入上下文。
 *
 * @param dispatchContextSnapshot 调度上下文快照
 * @param conservativePlan 是否生成保守计划
 */
public record OptimizationContext(
        DispatchContextSnapshot dispatchContextSnapshot,
        boolean conservativePlan
) {
}
