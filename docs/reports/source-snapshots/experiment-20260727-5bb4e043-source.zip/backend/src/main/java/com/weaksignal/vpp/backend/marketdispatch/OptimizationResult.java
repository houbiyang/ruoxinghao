package com.weaksignal.vpp.backend.marketdispatch;

import java.util.List;

/**
 * 优化结果。
 *
 * @param items 计划时间片集合
 */
public record OptimizationResult(List<DispatchPlanItem> items) {
}
