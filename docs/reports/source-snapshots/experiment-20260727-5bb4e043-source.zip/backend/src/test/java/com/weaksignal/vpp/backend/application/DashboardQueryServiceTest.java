package com.weaksignal.vpp.backend.application;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.weaksignal.vpp.backend.api.dto.DashboardSummaryResponse;
import com.weaksignal.vpp.backend.config.RedisCacheProperties;
import com.weaksignal.vpp.backend.domain.DemoScenario;
import com.weaksignal.vpp.backend.domain.LinkState;
import com.weaksignal.vpp.backend.domain.ResourceType;
import com.weaksignal.vpp.backend.infrastructure.persistence.entity.FaultEventEntity;
import com.weaksignal.vpp.backend.infrastructure.persistence.entity.StationEntity;
import com.weaksignal.vpp.backend.infrastructure.persistence.entity.TelemetrySnapshotEntity;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.FaultEventRepository;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.ResourceDeviceRepository;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.StationRepository;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.TelemetryHistoryRepository;
import com.weaksignal.vpp.backend.infrastructure.persistence.repository.TelemetrySnapshotRepository;
import com.weaksignal.vpp.backend.infrastructure.redis.RedisRealtimeStateStore;
import java.lang.reflect.Proxy;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;

/**
 * 总览查询服务测试。
 */
class DashboardQueryServiceTest {

    @Test
    void shouldExcludeOfflineStationsFromOnlineCount() {
        StationEntity onlineStation = new StationEntity();
        onlineStation.setStationId("pv-gobi-01");
        onlineStation.setStationName("光伏");
        onlineStation.setResourceType(ResourceType.PHOTOVOLTAIC);

        StationEntity offlineStation = new StationEntity();
        offlineStation.setStationId("wind-ridge-02");
        offlineStation.setStationName("风电");
        offlineStation.setResourceType(ResourceType.WIND);

        TelemetrySnapshotEntity onlineSnapshot = new TelemetrySnapshotEntity();
        onlineSnapshot.setStationId("pv-gobi-01");
        onlineSnapshot.setActivePower(120);
        onlineSnapshot.setAvailableCapacity(160);
        onlineSnapshot.setLatency(32);
        onlineSnapshot.setPacketLossRate(0.2);
        onlineSnapshot.setDataAge(1);
        onlineSnapshot.setOnline(true);
        onlineSnapshot.setLinkState(LinkState.S0);

        TelemetrySnapshotEntity offlineSnapshot = new TelemetrySnapshotEntity();
        offlineSnapshot.setStationId("wind-ridge-02");
        offlineSnapshot.setActivePower(80);
        offlineSnapshot.setAvailableCapacity(180);
        offlineSnapshot.setLatency(999);
        offlineSnapshot.setPacketLossRate(100);
        offlineSnapshot.setDataAge(20);
        offlineSnapshot.setOnline(false);
        offlineSnapshot.setLinkState(LinkState.S3);

        FaultEventEntity eventEntity = new FaultEventEntity();
        eventEntity.setLevel("严重");
        eventEntity.setOccurredAt(OffsetDateTime.parse("2026-06-29T21:30:00+08:00"));

        StationRepository stationRepository = repositoryProxy(
                StationRepository.class,
                Map.of("findAll", arguments -> List.of(onlineStation, offlineStation))
        );
        TelemetrySnapshotRepository snapshotRepository = repositoryProxy(
                TelemetrySnapshotRepository.class,
                Map.of(
                        "findByStationId", arguments -> {
                            String stationId = String.valueOf(arguments[0]);
                            if ("pv-gobi-01".equals(stationId)) {
                                return Optional.of(onlineSnapshot);
                            }
                            if ("wind-ridge-02".equals(stationId)) {
                                return Optional.of(offlineSnapshot);
                            }
                            return Optional.empty();
                        }
                )
        );
        FaultEventRepository faultEventRepository = repositoryProxy(
                FaultEventRepository.class,
                Map.of("findAllByOrderByOccurredAtDesc", arguments -> List.of(eventEntity))
        );

        RedisRealtimeStateStore realtimeStateStore = new RedisRealtimeStateStore(
                null,
                new ObjectMapper().findAndRegisterModules(),
                new RedisCacheProperties(45, 20)
        ) {
            @Override
            public Optional<DemoScenario> getActiveScenario() {
                return Optional.of(DemoScenario.LOST);
            }
        };

        DashboardQueryService service = new DashboardQueryService(
                stationRepository,
                snapshotRepository,
                repositoryProxy(TelemetryHistoryRepository.class, Map.of()),
                repositoryProxy(ResourceDeviceRepository.class, Map.of()),
                faultEventRepository,
                new StationLayoutRegistry(),
                realtimeStateStore,
                Clock.fixed(OffsetDateTime.parse("2026-06-29T21:30:00+08:00").toInstant(), ZoneId.of("Asia/Shanghai"))
        );

        DashboardSummaryResponse summary = service.getDashboardSummary();

        assertEquals(1, summary.onlineStationCount());
        assertEquals(1, summary.alarmCount());
        assertEquals(DemoScenario.LOST, summary.activeScenario());
        assertEquals(200.0, summary.totalOutputPower());
    }

    @SuppressWarnings("unchecked")
    private <T> T repositoryProxy(Class<T> type, Map<String, java.util.function.Function<Object[], Object>> handlers) {
        return (T) Proxy.newProxyInstance(
                type.getClassLoader(),
                new Class<?>[]{type},
                (proxy, method, args) -> {
                    java.util.function.Function<Object[], Object> handler = handlers.get(method.getName());
                    if (handler != null) {
                        return handler.apply(args == null ? new Object[0] : args);
                    }
                    if (method.getReturnType().equals(boolean.class)) {
                        return false;
                    }
                    return null;
                }
        );
    }
}
