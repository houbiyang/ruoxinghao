<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink, RouterView, useRoute } from 'vue-router'

const route = useRoute()

const navigationItems = [
  { name: '总览驾驶舱', path: '/' },
  { name: '场站实时监控', path: '/stations' },
  { name: '链路质量监测', path: '/links' },
  { name: '调度与控制面板', path: '/dispatch' },
  { name: '多智能体调度中心', path: '/agent-dispatch' },
  { name: '市场与电价', path: '/market-pricing' },
  { name: '故障注入实验台', path: '/fault-lab' },
  { name: '实验结果对比', path: '/results' },
  { name: '告警与事件中心', path: '/events' },
  { name: '系统配置', path: '/settings' }
]

const isNavigationActive = computed(() => {
  return (path: string) => {
    if (path === '/') {
      return route.path === '/'
    }

    return route.path === path || route.path.startsWith(`${path}/`)
  }
})

const isFullScreenRoute = computed(() => {
  return route.path === '/agent-dispatch'
    || route.path === '/market-pricing'
    || route.path === '/fault-lab'
    || route.path === '/results'
})
</script>

<template>
  <div class="app-shell" :class="{ 'app-shell--agent-dispatch': isFullScreenRoute }">
    <header v-if="!isFullScreenRoute" class="app-topbar">
      <div class="app-topbar__title">弱信号覆盖下新能源场站虚拟电厂</div>
      <nav class="app-topbar__nav" aria-label="主导航">
        <RouterLink
          v-for="item in navigationItems"
          :key="item.path"
          :to="item.path"
          class="app-topbar__link"
          :class="{ 'is-active': isNavigationActive(item.path) }"
        >
          {{ item.name }}
        </RouterLink>
      </nav>
    </header>

    <main class="app-main">
      <RouterView />
    </main>
  </div>
</template>
