<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import type { EChartsOption, LineSeriesOption } from 'echarts'

import EChartPanel from '@/components/charts/EChartPanel.vue'

type PowerSample = {
  time: number
  photovoltaicPower: number
  thermalPower: number
  windPower: number
  gridPower: number
  storagePower: number
  chargingPower: number
  loadPower: number
  unmanagedGridPower: number
}

type DispatchActionItem = {
  title: string
  detail: string
  tone: 'green' | 'blue' | 'cyan' | 'purple'
}

const SAMPLE_INTERVAL_MS = 1000
const DISPLAY_WINDOW_MS = 5 * 60 * 1000
const INTERVENTION_OFFSET_MS = 2 * 60 * 1000
const INITIAL_SAMPLE_COUNT = DISPLAY_WINDOW_MS / SAMPLE_INTERVAL_MS
const powerSamples = ref<PowerSample[]>([])
const interventionTime = ref(Date.now() - INTERVENTION_OFFSET_MS)

let sampleTimer: number | undefined
let sampleSequence = 0

function roundPower(value: number): number {
  return Math.round(value * 10) / 10
}

function clamp(value: number, minimum: number, maximum: number): number {
  return Math.min(maximum, Math.max(minimum, value))
}

function calculateAxisMinimum(value: { min: number, max: number }): number {
  const padding = Math.max(8, (value.max - value.min) * 0.08)
  return Math.floor((value.min - padding) / 10) * 10
}

function calculateAxisMaximum(value: { min: number, max: number }): number {
  const padding = Math.max(8, (value.max - value.min) * 0.08)
  return Math.ceil((value.max + padding) / 10) * 10
}

function createPowerSample(time: number, sampleIndex: number): PowerSample {
  const elapsedSeconds = sampleIndex
  const photovoltaicPower = roundPower(
    68 + Math.sin(elapsedSeconds / 18) * 4.6 + Math.sin(elapsedSeconds / 7) * 1.4
  )
  const thermalPower = roundPower(
    23 + Math.sin(elapsedSeconds / 31) * 1.8 + Math.sin(elapsedSeconds / 10) * 0.8
  )
  const windPower = roundPower(
    36 + Math.sin(elapsedSeconds / 15) * 5.4 + Math.sin(elapsedSeconds / 4.5) * 1.6
  )
  const chargingPower = roundPower(
    24 + Math.sin(elapsedSeconds / 20) * 3.2 + Math.sin(elapsedSeconds / 5.5) * 1.1
  )
  const loadPower = roundPower(
    116 + Math.sin(elapsedSeconds / 23) * 8.5 + Math.sin(elapsedSeconds / 6) * 3.2
  )
  const unmanagedGridPower = loadPower + chargingPower - photovoltaicPower - thermalPower - windPower
  const isAgentActive = time >= interventionTime.value

  if (!isAgentActive) {
    const gridPower = roundPower(
      Math.max(0, unmanagedGridPower + Math.sin(elapsedSeconds / 3.2) * 8.4 + Math.sin(elapsedSeconds / 1.7) * 3.1)
    )
    return {
      time,
      photovoltaicPower,
      thermalPower,
      windPower,
      gridPower,
      storagePower: 0,
      chargingPower,
      loadPower,
      unmanagedGridPower
    }
  }

  const gridTarget = 54 + Math.sin(elapsedSeconds / 38) * 1.8
  const storagePower = roundPower(clamp(unmanagedGridPower - gridTarget, -18, 26))
  const gridPower = roundPower(Math.max(0, unmanagedGridPower - storagePower + Math.sin(elapsedSeconds / 13) * 0.7))

  return {
    time,
    photovoltaicPower,
    thermalPower,
    windPower,
    gridPower,
    storagePower,
    chargingPower,
    loadPower,
    unmanagedGridPower
  }
}

function initializePowerSamples(): void {
  const now = Date.now()
  powerSamples.value = Array.from({ length: INITIAL_SAMPLE_COUNT }, (_, index) => {
    const time = now - (INITIAL_SAMPLE_COUNT - 1 - index) * SAMPLE_INTERVAL_MS
    return createPowerSample(time, index)
  })
  sampleSequence = INITIAL_SAMPLE_COUNT
}

function appendPowerSample(): void {
  const time = Date.now()
  const cutoffTime = time - DISPLAY_WINDOW_MS
  powerSamples.value = [
    ...powerSamples.value.filter((sample) => sample.time >= cutoffTime),
    createPowerSample(time, sampleSequence)
  ]
  sampleSequence += 1
}

function buildPowerLine(
  name: string,
  field: keyof Omit<PowerSample, 'time' | 'unmanagedGridPower'>,
  color: string,
  yAxisIndex: number
): LineSeriesOption {
  return {
    name,
    type: 'line',
    yAxisIndex,
    smooth: 0.22,
    symbol: 'circle',
    symbolSize: 4,
    showSymbol: true,
    sampling: 'lttb',
    lineStyle: { width: 2, color },
    itemStyle: { color },
    data: powerSamples.value.map((sample) => [sample.time, sample[field]])
  }
}

const latestSample = computed(() => powerSamples.value[powerSamples.value.length - 1])

const dispatchStatus = computed(() => {
  return (latestSample.value?.time ?? 0) >= interventionTime.value ? '智能体调度中' : '调度前'
})

const currentPeakReduction = computed(() => {
  if (!latestSample.value) {
    return 0
  }
  return Math.max(0, latestSample.value.unmanagedGridPower - latestSample.value.gridPower)
})

const photovoltaicConsumptionRate = computed(() => {
  const current = latestSample.value
  if (!current || current.photovoltaicPower <= 0) {
    return 0
  }
  const surplusPower = Math.max(0, current.photovoltaicPower - current.loadPower)
  const absorbedSurplus = current.storagePower < 0 ? Math.min(surplusPower, Math.abs(current.storagePower)) : 0
  const curtailedPower = Math.max(0, surplusPower - absorbedSurplus)
  return Math.max(0, Math.min(100, ((current.photovoltaicPower - curtailedPower) / current.photovoltaicPower) * 100))
})

const storageStatus = computed(() => {
  const storagePower = latestSample.value?.storagePower ?? 0
  if (storagePower > 0.5) {
    return `放电 ${formatPower(storagePower)} kW`
  }
  if (storagePower < -0.5) {
    return `充电 ${formatPower(Math.abs(storagePower))} kW`
  }
  return '待机'
})

const dispatchActionItems = computed<DispatchActionItem[]>(() => {
  const chargingPower = latestSample.value?.chargingPower ?? 0
  const peakReduction = currentPeakReduction.value

  return [
    {
      title: '新能源优先消纳',
      detail: `光伏消纳率 ${formatPower(photovoltaicConsumptionRate.value)}%`,
      tone: 'green'
    },
    {
      title: '储能动态调节',
      detail: storageStatus.value,
      tone: 'cyan'
    },
    {
      title: '市电削峰平滑',
      detail: peakReduction > 0.5 ? `当前削峰 ${formatPower(peakReduction)} kW` : '维持平滑购电',
      tone: 'blue'
    },
    {
      title: '充电桩错峰用电',
      detail: `当前充电功率 ${formatPower(chargingPower)} kW`,
      tone: 'purple'
    }
  ]
})

function formatPower(value: number): string {
  return value.toFixed(1)
}

const powerCurveOption = computed<EChartsOption>(() => ({
  animationDurationUpdate: 350,
  color: ['#f7b84b', '#ff7866', '#58d77a', '#3d9cff', '#42d785', '#49d7f2', '#a46bff'],
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(4, 22, 52, 0.96)',
    borderColor: 'rgba(71, 159, 255, 0.45)',
    textStyle: { color: '#dceaff' },
    valueFormatter: (value) => `${Number(value).toFixed(1)} kW`
  },
  legend: {
    top: 4,
    left: 12,
    right: 12,
    itemWidth: 16,
    itemHeight: 7,
    itemGap: 12,
    selectedMode: true,
    textStyle: { color: '#b9c9e7', fontSize: 12 },
    data: ['光伏发电', '火电发电', '风电发电', '市电购电', '储能充放电', '充电桩用电', '负载用电']
  },
  grid: { top: 76, left: 72, right: 72, bottom: 42 },
  xAxis: {
    type: 'time',
    min: (latestSample.value?.time ?? Date.now()) - DISPLAY_WINDOW_MS,
    max: latestSample.value?.time ?? Date.now(),
    axisLabel: {
      color: '#a8bbd8',
      formatter: (value: number) => new Intl.DateTimeFormat('zh-CN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).format(new Date(value))
    },
    axisTick: { show: false },
    axisLine: { lineStyle: { color: 'rgba(83, 132, 190, 0.45)' } },
    splitLine: { show: false }
  },
  yAxis: [
    {
      type: 'value',
      scale: true,
      name: '负荷 / 光伏（kW）',
      min: calculateAxisMinimum,
      max: calculateAxisMaximum,
      nameTextStyle: { color: '#b4c7df', align: 'left' },
      axisLabel: { color: '#a8bbd8' },
      splitLine: { lineStyle: { color: 'rgba(62, 104, 158, 0.28)' } }
    },
    {
      type: 'value',
      scale: true,
      position: 'right',
      name: '调节资源（kW）',
      min: calculateAxisMinimum,
      max: calculateAxisMaximum,
      nameTextStyle: { color: '#b4c7df', align: 'right' },
      axisLabel: { color: '#a8bbd8' },
      splitLine: { show: false }
    }
  ],
  series: [
    buildPowerLine('光伏发电', 'photovoltaicPower', '#f7b84b', 0),
    buildPowerLine('火电发电', 'thermalPower', '#ff7866', 1),
    buildPowerLine('风电发电', 'windPower', '#58d77a', 1),
    {
      ...buildPowerLine('市电购电', 'gridPower', '#3d9cff', 1),
      markLine: {
        symbol: 'none',
        silent: true,
        lineStyle: { color: '#63e6ff', width: 2, type: 'dashed' },
        label: {
          show: true,
          formatter: '智能体介入时间',
          color: '#dff9ff',
          backgroundColor: 'rgba(15, 99, 153, 0.9)',
          padding: [5, 8],
          borderRadius: 4
        },
        data: [{ xAxis: interventionTime.value }]
      }
    },
    buildPowerLine('储能充放电', 'storagePower', '#42d785', 1),
    buildPowerLine('充电桩用电', 'chargingPower', '#49d7f2', 1),
    buildPowerLine('负载用电', 'loadPower', '#a46bff', 0)
  ]
}))

onMounted(() => {
  initializePowerSamples()
  sampleTimer = window.setInterval(appendPowerSample, SAMPLE_INTERVAL_MS)
})

onBeforeUnmount(() => {
  if (sampleTimer !== undefined) {
    window.clearInterval(sampleTimer)
  }
})
</script>

<template>
  <article class="dispatch-card agent-power-card">
    <header class="agent-power-header">
      <div>
        <h2>智能体调度功率曲线</h2>
        <p>最近 5 分钟 · 每秒更新</p>
      </div>
      <span class="agent-power-status" :class="{ 'is-active': dispatchStatus === '智能体调度中' }">
        <i />{{ dispatchStatus }}
      </span>
    </header>

    <div class="agent-power-chart">
      <EChartPanel :option="powerCurveOption" height="350px" />
      <aside v-if="dispatchStatus === '智能体调度中'" class="agent-power-actions" aria-label="智能体调度动作">
        <h3>本轮调度动作</h3>
        <ul>
          <li v-for="item in dispatchActionItems" :key="item.title" :class="`is-${item.tone}`">
            <i />
            <div>
              <strong>{{ item.title }}</strong>
              <span>{{ item.detail }}</span>
            </div>
          </li>
        </ul>
      </aside>
    </div>

    <dl class="agent-power-summary">
      <div>
        <dt>当前市电削峰值</dt>
        <dd>{{ formatPower(currentPeakReduction) }} <small>kW</small></dd>
      </div>
      <div>
        <dt>光伏消纳率</dt>
        <dd>{{ formatPower(photovoltaicConsumptionRate) }}<small>%</small></dd>
      </div>
      <div>
        <dt>储能当前状态</dt>
        <dd class="is-storage">{{ storageStatus }}</dd>
      </div>
    </dl>
  </article>
</template>

<style scoped>
.agent-power-card {
  overflow: hidden;
}

.agent-power-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 62px;
  padding: 0 22px;
  border-bottom: 1px solid rgba(71, 128, 194, 0.16);
}

.agent-power-header h2 {
  margin: 0;
  color: #ffffff;
  font-size: 20px;
}

.agent-power-header p {
  margin: 5px 0 0;
  color: #8198b8;
  font-size: 12px;
}

.agent-power-status {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 7px 12px;
  color: #a9bdd8;
  font-size: 13px;
  border: 1px solid rgba(80, 142, 212, 0.36);
  border-radius: 16px;
  background: rgba(7, 30, 67, 0.72);
}

.agent-power-status i {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #71839a;
}

.agent-power-status.is-active {
  color: #72f6a3;
  border-color: rgba(66, 215, 133, 0.38);
  background: rgba(17, 92, 60, 0.28);
}

.agent-power-status.is-active i {
  background: #42d785;
  box-shadow: 0 0 8px rgba(66, 215, 133, 0.9);
}

.agent-power-chart {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 174px;
  gap: 12px;
  padding: 12px;
}

.agent-power-actions {
  padding: 14px 12px;
  border: 1px solid rgba(64, 143, 235, 0.28);
  border-radius: 6px;
  background: rgba(7, 30, 67, 0.72);
}

.agent-power-actions h3 {
  margin: 0 0 12px;
  color: #e8f4ff;
  font-size: 13px;
}

.agent-power-actions ul {
  display: grid;
  gap: 14px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.agent-power-actions li {
  display: grid;
  grid-template-columns: 8px minmax(0, 1fr);
  gap: 8px;
}

.agent-power-actions li > i {
  width: 7px;
  height: 7px;
  margin-top: 5px;
  border-radius: 50%;
  background: #60d987;
  box-shadow: 0 0 7px rgba(96, 217, 135, 0.7);
}

.agent-power-actions li.is-blue > i {
  background: #48a4ff;
  box-shadow: 0 0 7px rgba(72, 164, 255, 0.7);
}

.agent-power-actions li.is-cyan > i {
  background: #49d7f2;
  box-shadow: 0 0 7px rgba(73, 215, 242, 0.7);
}

.agent-power-actions li.is-purple > i {
  background: #a46bff;
  box-shadow: 0 0 7px rgba(164, 107, 255, 0.7);
}

.agent-power-actions strong,
.agent-power-actions span {
  display: block;
}

.agent-power-actions strong {
  color: #dceaff;
  font-size: 12px;
}

.agent-power-actions span {
  margin-top: 4px;
  color: #91a8c8;
  font-size: 11px;
  line-height: 1.45;
}

.agent-power-summary {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 1px;
  margin: 0;
  border-top: 1px solid rgba(71, 128, 194, 0.16);
  background: rgba(71, 128, 194, 0.16);
}

.agent-power-summary div {
  padding: 14px 22px;
  background: rgba(4, 24, 56, 0.96);
}

.agent-power-summary dt {
  color: #91a8c8;
  font-size: 12px;
}

.agent-power-summary dd {
  margin: 6px 0 0;
  color: #48a4ff;
  font-size: 20px;
  font-weight: 700;
}

.agent-power-summary dd.is-storage {
  color: #42d785;
}

.agent-power-summary small {
  margin-left: 3px;
  color: #b8cbe3;
  font-size: 12px;
  font-weight: 500;
}

@media (max-width: 720px) {
  .agent-power-header {
    align-items: flex-start;
    gap: 12px;
    padding: 14px 16px;
  }

  .agent-power-header h2 {
    font-size: 17px;
  }

  .agent-power-status {
    flex: 0 0 auto;
    padding: 6px 9px;
    font-size: 11px;
  }

  .agent-power-chart {
    margin: 0 -4px;
    padding: 0;
  }

  .agent-power-summary {
    grid-template-columns: 1fr;
  }
}
</style>
