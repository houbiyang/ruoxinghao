import { createRouter, createWebHistory } from 'vue-router'

import OverviewDashboardView from '@/views/OverviewDashboardView.vue'
import ExperimentResultsView from '@/views/ExperimentResultsView.vue'
import EventCenterView from '@/views/EventCenterView.vue'
import FaultLabView from '@/views/FaultLabView.vue'
import LinkQualityView from '@/views/LinkQualityView.vue'
import DispatchControlView from '@/views/DispatchControlView.vue'
import MultiAgentDispatchCenterView from '@/views/MultiAgentDispatchCenterView.vue'
import MarketPricingView from '@/views/MarketPricingView.vue'
import SectionPlaceholderView from '@/views/SectionPlaceholderView.vue'
import StationDetailView from '@/views/StationDetailView.vue'
import StationOverviewView from '@/views/StationOverviewView.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'overview',
      component: OverviewDashboardView,
      meta: {
        title: '总览驾驶舱'
      }
    },
    {
      path: '/stations',
      name: 'stations',
      component: StationOverviewView,
      meta: {
        title: '场站实时监控',
        overview:
          '聚焦单场站实时遥测、设备态势、边缘控制回执与本地自治策略窗口，为后续接入 MQTT 遥测与设备故障诊断提供承载面。',
        modules: ['场站拓扑概览', '设备状态矩阵', '实时功率与SOC曲线', '本地控制日志']
      }
    },
    {
      path: '/stations/:stationId',
      name: 'station-detail',
      component: StationDetailView,
      meta: {
        title: '资源专题监控'
      }
    },
    {
      path: '/links',
      name: 'links',
      component: LinkQualityView,
      meta: {
        title: '链路质量监测',
        overview:
          '用于承载链路时延、丢包、信号覆盖热区、卫星/专网/公网多链路切换记录，突出弱信号场景的通信治理能力。',
        modules: ['链路质量地图', '时延与抖动趋势', '链路切换日志', '弱信号恢复回放']
      }
    },
    {
      path: '/dispatch',
      name: 'dispatch',
      component: DispatchControlView,
      meta: {
        title: '调度与控制面板',
        overview:
          '承载日内计划、滚动优化、边缘约束参数与控制下发回执，当前阶段只冻结布局和视觉语言，不接入真实调度算法。',
        modules: ['日内计划窗口', '边缘协同策略面板', '控制指令回执', '执行状态总览']
      }
    },
    {
      path: '/agent-dispatch',
      name: 'agent-dispatch',
      component: MultiAgentDispatchCenterView,
      meta: {
        title: '多智能体调度中心'
      }
    },
    {
      path: '/market-pricing',
      name: 'market-pricing',
      component: MarketPricingView,
      meta: {
        title: '市场与电价'
      }
    },
    {
      path: '/fault-lab',
      name: 'fault-lab',
      component: FaultLabView,
      meta: {
        title: '故障注入实验台'
      }
    },
    {
      path: '/results',
      name: 'results',
      component: ExperimentResultsView,
      meta: {
        title: '实验结果对比'
      }
    },
    {
      path: '/events',
      name: 'events',
      component: EventCenterView,
      meta: {
        title: '告警与事件中心',
        overview:
          '汇聚分级告警、链路事件、场站回执与恢复动作，形成赛场演示时可追踪的事件叙事链。',
        modules: ['多级告警列表', '事件检索条件', '处置流程卡片', '恢复闭环摘要']
      }
    },
    {
      path: '/settings',
      name: 'settings',
      component: SectionPlaceholderView,
      meta: {
        title: '系统配置',
        overview:
          '预留展示主题配置、演示模式切换、数据源适配开关与通信参数模板，后续阶段再接入真实配置项。',
        modules: ['演示模式开关', '通信模板参数', '主题与屏幕配置', '数据适配层留位']
      }
    }
  ]
})

export default router
