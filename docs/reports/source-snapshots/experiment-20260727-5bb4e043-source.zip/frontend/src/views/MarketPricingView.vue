<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import type { EChartsOption } from 'echarts'

import { fetchMarketDashboardOverview } from '@/api/systemApi'
import EChartPanel from '@/components/charts/EChartPanel.vue'
import type { MarketDashboardOverview, MarketDashboardRange } from '@/types/system'

type PriceTrendPoint = {
  time: string
  realtime: number
  dayAhead: number
  forecastToday: number
  forecastTomorrow: number
}

type PriceTableRow = {
  period: string
  realtime: number | string
  dayAhead: number | string
  forecastToday: number | string
  forecastTomorrow: number | string
}

type RecommendationCard = {
  title: string
  description: string
  valueLabel: string
  value: string
  tone: 'green' | 'orange' | 'blue'
}

type MarketNewsItem = {
  publishedAt: string
  title: string
}

type DistributionItem = {
  name: string
  value: number
  color: string
}

type MetricCard = {
  title: string
  value: string
  unit: string
  subLabel: string
  delta: string
  tone: string
  sparkline?: number[]
  progress?: number
}

const currentDateTime = ref('')
const screenWidth = ref(typeof window === 'undefined' ? 1536 : window.innerWidth)
const dashboardOverview = ref<MarketDashboardOverview | null>(null)
const dashboardLoading = ref(false)
const dashboardError = ref('')
const lastUpdatedAt = ref('')
let timerId = 0

const primaryTabs = ['总览驾驶舱', '调度中心', '多智能体中心', '市场与电价', '数据分析', '系统管理']
const leftMenuItems = [
  '总览驾驶舱',
  '实时监控',
  '调度中心',
  '多智能体中心',
  '市场与电价',
  '故障注入实验',
  '实验结果对比',
  '回放分析',
  '设备管理',
  '告警管理',
  '报表中心',
  '系统管理'
]
const marketTypes = ['日前市场', '实时市场', '辅助服务']
const periodTabs = ['24小时', '48小时', '7天']
const analysisTabs = ['趋势预测', '波动分析', '影响因素']

const activePrimaryTab = ref('市场与电价')
const activeLeftMenu = ref('市场与电价')
const activeMarketType = ref('日前市场')
const activeMarketTab = ref('实时市场')
const activePeriodTab = ref('24小时')
const activeAnalysisTab = ref('趋势预测')

const periodRangeMap: Record<string, MarketDashboardRange> = {
  '24小时': '24H',
  '48小时': '48H',
  '7天': '7D'
}

const distributionColors = ['#2f89ff', '#55c7ff', '#f5b13a', '#ff8c2f', '#ff5d4d']

const marketSummary = computed(() => dashboardOverview.value?.summary)

const statCards = computed<MetricCard[]>(() => {
  const summary = dashboardOverview.value?.summary
  const sparklines = dashboardOverview.value?.summarySparklines
  return [
    {
      title: '当前实时电价',
      value: formatDecimal(summary?.currentRealTimePrice),
      unit: '元/kWh',
      subLabel: '实时市场',
      delta: `${formatDecimal(summary?.currentRealTimePrice)} 元/kWh`,
      tone: 'green',
      sparkline: normalizeSparkline(sparklines?.realTimePriceTrend)
    },
    {
      title: `预计高峰电价(${summary?.peakForecastWindow ?? '18:00-21:00'})`,
      value: formatDecimal(summary?.peakForecastPrice),
      unit: '元/kWh',
      subLabel: '高峰窗口',
      delta: `${formatDecimal(summary?.peakForecastPrice)} 元/kWh`,
      tone: 'orange',
      sparkline: normalizeSparkline(sparklines?.peakForecastTrend)
    },
    {
      title: '合同电量',
      value: formatDecimal(summary?.contractEnergyMwh),
      unit: 'MWh',
      subLabel: '已执行',
      delta: `${formatDecimal(summary?.executedEnergyMwh)} MWh`,
      tone: 'blue',
      progress: toNumber(summary?.contractProgressPercent)
    },
    {
      title: '日内预测平均电价',
      value: formatDecimal(summary?.averageForecastPrice),
      unit: '元/kWh',
      subLabel: '预测均价',
      delta: `${formatDecimal(summary?.averageForecastPrice)} 元/kWh`,
      tone: 'purple',
      sparkline: normalizeSparkline(sparklines?.averageForecastTrend)
    },
    {
      title: '市场交易量(今日)',
      value: formatInteger(summary?.todayTradeVolumeMwh),
      unit: 'MWh',
      subLabel: '已出清',
      delta: `${formatDecimal(summary?.todayTradeVolumeMwh)} MWh`,
      tone: 'cyan',
      sparkline: normalizeSparkline(sparklines?.tradeVolumeTrend)
    }
  ]
})

const marketNews = computed<MarketNewsItem[]>(() => dashboardOverview.value?.news ?? [])

const recommendationCards = computed<RecommendationCard[]>(() => {
  return dashboardOverview.value?.recommendations.map((item) => ({
    title: item.title,
    description: item.description,
    valueLabel: item.valueLabel,
    value: `${formatCurrency(item.value)} 元`,
    tone: item.tone
  })) ?? []
})

const priceTrendData = computed<PriceTrendPoint[]>(() => {
  return dashboardOverview.value?.priceTrend.points.map((item) => ({
    time: item.time,
    realtime: toNumber(item.realTimePrice),
    dayAhead: toNumber(item.dayAheadPrice),
    forecastToday: toNumber(item.forecastTodayPrice),
    forecastTomorrow: toNumber(item.forecastTomorrowPrice)
  })) ?? []
})

const tableRows = computed<PriceTableRow[]>(() => {
  return dashboardOverview.value?.timeOfUsePrices.map((item) => ({
    period: item.period,
    realtime: toNumber(item.realTimePrice),
    dayAhead: toNumber(item.dayAheadPrice),
    forecastToday: toNumber(item.forecastTodayPrice),
    forecastTomorrow: toNumber(item.forecastTomorrowPrice)
  })) ?? []
})

const distributionData = computed<DistributionItem[]>(() => {
  return dashboardOverview.value?.distribution.map((item, index) => ({
    name: item.bucket,
    value: toNumber(item.percentage),
    color: distributionColors[index] ?? '#6ca8ff'
  })) ?? []
})

const statusItems = computed(() => dashboardOverview.value?.dataSourceStatus ?? [])

const predictionConclusion = computed(() => {
  if (dashboardError.value) {
    return dashboardError.value
  }
  if (dashboardLoading.value) {
    return '正在加载市场与电价聚合数据。'
  }
  return dashboardOverview.value?.predictionAnalysis.conclusion ?? '暂无预测结论。'
})

const predictionTodayTrend = computed(() => dashboardOverview.value?.predictionAnalysis.todayTrend ?? [])
const predictionTomorrowTrend = computed(() => dashboardOverview.value?.predictionAnalysis.tomorrowTrend ?? [])

const trendChartOption = computed<EChartsOption>(() => ({
  animationDuration: 700,
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(6, 20, 54, 0.96)',
    borderColor: 'rgba(91, 174, 255, 0.35)',
    textStyle: { color: '#e6f2ff' }
  },
  legend: {
    top: 0,
    left: 16,
    textStyle: { color: '#b6c9ef', fontSize: 12 },
    itemWidth: 16,
    itemHeight: 6,
    data: ['实时电价', '日前电价', '预测电价(今天)', '预测电价(明天)']
  },
  grid: { top: 44, left: 48, right: 18, bottom: 28 },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: priceTrendData.value.map((item) => item.time),
    axisLabel: { color: '#8ca9d6', fontSize: 11 },
    axisLine: { lineStyle: { color: 'rgba(76, 110, 170, 0.45)' } },
    axisTick: { show: false }
  },
  yAxis: {
    type: 'value',
    name: '元/kWh',
    min: 0,
    max: 1.5,
    interval: 0.3,
    nameTextStyle: { color: '#8ca9d6', padding: [0, 0, 0, -8] },
    axisLabel: { color: '#8ca9d6', fontSize: 11 },
    axisLine: { show: false },
    splitLine: { lineStyle: { color: 'rgba(57, 86, 135, 0.32)' } }
  },
  series: [
    buildLineSeries('实时电价', '#6be97f', priceTrendData.value.map((item) => item.realtime)),
    buildLineSeries('日前电价', '#46a0ff', priceTrendData.value.map((item) => item.dayAhead)),
    buildLineSeries('预测电价(今天)', '#ffb33d', priceTrendData.value.map((item) => item.forecastToday)),
    buildLineSeries('预测电价(明天)', '#9d69ff', priceTrendData.value.map((item) => item.forecastTomorrow))
  ]
}))

const predictionChartOption = computed<EChartsOption>(() => ({
  animationDuration: 700,
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(6, 20, 54, 0.96)',
    borderColor: 'rgba(91, 174, 255, 0.35)',
    textStyle: { color: '#e6f2ff' }
  },
  legend: {
    top: 0,
    center: true,
    textStyle: { color: '#b6c9ef', fontSize: 12 },
    itemWidth: 16,
    itemHeight: 6,
    data: ['预测电价(今日)', '预测电价(明日)']
  },
  grid: { top: 34, left: 40, right: 12, bottom: 28 },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: predictionTodayTrend.value.map((item) => item.time),
    axisLabel: { color: '#8ca9d6', fontSize: 11, interval: 5 },
    axisLine: { lineStyle: { color: 'rgba(76, 110, 170, 0.45)' } },
    axisTick: { show: false }
  },
  yAxis: {
    type: 'value',
    name: '元/kWh',
    min: 0,
    max: 1.5,
    interval: 0.3,
    nameTextStyle: { color: '#8ca9d6' },
    axisLabel: { color: '#8ca9d6', fontSize: 11 },
    axisLine: { show: false },
    splitLine: { lineStyle: { color: 'rgba(57, 86, 135, 0.32)' } }
  },
  series: [
    buildLineSeries('预测电价(今日)', '#ffb33d', predictionTodayTrend.value.map((item) => toNumber(item.price))),
    buildLineSeries('预测电价(明日)', '#9d69ff', predictionTomorrowTrend.value.map((item) => toNumber(item.price)))
  ]
}))

const bottomLayoutStyle = computed(() => {
  if (screenWidth.value <= 1320) {
    return {
      display: 'grid',
      gridTemplateColumns: '1fr'
    }
  }

  return {
    display: 'flex',
    alignItems: 'stretch'
  }
})

const distributionChartOption = computed<EChartsOption>(() => ({
  tooltip: {
    trigger: 'item',
    backgroundColor: 'rgba(6, 20, 54, 0.96)',
    borderColor: 'rgba(91, 174, 255, 0.35)',
    textStyle: { color: '#e6f2ff' },
    formatter: '{b}<br />占比：{c}%'
  },
  series: [
    {
      type: 'pie',
      radius: ['55%', '76%'],
      center: ['36%', '50%'],
      avoidLabelOverlap: false,
      label: { show: false },
      itemStyle: { borderColor: '#0b1f48', borderWidth: 2 },
      data: distributionData.value.map((item) => ({
        name: item.name,
        value: item.value,
        itemStyle: { color: item.color }
      }))
    }
  ]
}))

function buildLineSeries(name: string, color: string, data: number[]) {
  return {
    name,
    type: 'line',
    smooth: true,
    symbol: 'circle',
    symbolSize: 6,
    lineStyle: { color, width: 2 },
    itemStyle: { color },
    data
  }
}

async function loadMarketDashboardOverview(): Promise<void> {
  dashboardLoading.value = true
  dashboardError.value = ''
  try {
    dashboardOverview.value = await fetchMarketDashboardOverview(periodRangeMap[activePeriodTab.value] ?? '24H', 5)
    lastUpdatedAt.value = formatDateTime(new Date())
  } catch (error) {
    dashboardError.value = error instanceof Error ? error.message : '市场与电价数据加载失败'
  } finally {
    dashboardLoading.value = false
  }
}

function toNumber(value: number | string | null | undefined): number {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : 0
  }
  if (typeof value === 'string') {
    const parsedValue = Number(value)
    return Number.isFinite(parsedValue) ? parsedValue : 0
  }
  return 0
}

function formatDecimal(value: number | string | null | undefined): string {
  return toNumber(value).toFixed(2)
}

function formatInteger(value: number | string | null | undefined): string {
  return Math.round(toNumber(value)).toLocaleString('zh-CN')
}

function formatCurrency(value: number | string | null | undefined): string {
  return toNumber(value).toLocaleString('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })
}

function normalizeSparkline(values: Array<number | string> | undefined): number[] {
  const numericValues = values?.map(toNumber) ?? []
  if (numericValues.length === 0) {
    return []
  }
  const maximumValue = Math.max(...numericValues, 1)
  return numericValues.map((value) => Math.max(0.08, Math.min(0.92, value / maximumValue)))
}

function formatNumber(value: number | string): string {
  return typeof value === 'number' ? value.toFixed(2) : value
}

function formatDateTime(date: Date): string {
  return new Intl.DateTimeFormat('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }).format(date).replace(/\//g, '-')
}

function formatNewsTime(value: string): string {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) {
    return '--'
  }
  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).format(date).replace(/\//g, '-')
}

function updateCurrentDateTime(): void {
  currentDateTime.value = formatDateTime(new Date())
}

function updateScreenWidth(): void {
  screenWidth.value = window.innerWidth
}

function trendClass(value: number | string): string {
  if (typeof value !== 'number') {
    return ''
  }
  if (value >= 1) {
    return 'is-hot'
  }
  if (value >= 0.8) {
    return 'is-warm'
  }
  return 'is-cool'
}

function recommendationToneClass(tone: RecommendationCard['tone']): string {
  return `is-${tone}`
}

onMounted(() => {
  updateCurrentDateTime()
  updateScreenWidth()
  void loadMarketDashboardOverview()
  timerId = window.setInterval(updateCurrentDateTime, 1000)
  window.addEventListener('resize', updateScreenWidth)
})

watch(activePeriodTab, () => {
  void loadMarketDashboardOverview()
})

onBeforeUnmount(() => {
  window.clearInterval(timerId)
  window.removeEventListener('resize', updateScreenWidth)
})
</script>

<template>
  <section class="market-screen">
    <header class="market-screen__topbar">
      <div class="market-brand">
        <div class="market-brand__logo" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>
        <div class="market-brand__title">虚拟电厂智能调度平台</div>
      </div>

      <nav class="market-primary-nav" aria-label="顶部导航">
        <button
          v-for="tab in primaryTabs"
          :key="tab"
          type="button"
          class="market-primary-nav__item"
          :class="{ 'is-active': tab === activePrimaryTab }"
          @click="activePrimaryTab = tab"
        >
          {{ tab }}
        </button>
      </nav>

      <div class="market-topbar__status">
        <div class="market-topbar__time">{{ currentDateTime }}</div>
        <div class="market-topbar__weather">26℃</div>
        <div class="market-topbar__alarm">告警 3</div>
        <div class="market-topbar__user">调度员</div>
      </div>
    </header>

    <div class="market-screen__body">
      <aside class="market-sidebar">
        <div class="market-sidebar__menu">
          <button
            v-for="item in leftMenuItems"
            :key="item"
            type="button"
            class="market-sidebar__item"
            :class="{ 'is-active': item === activeLeftMenu }"
            @click="activeLeftMenu = item"
          >
            <span class="market-sidebar__icon" aria-hidden="true" />
            <span>{{ item }}</span>
          </button>
        </div>

        <div class="market-sidebar__status-card">
          <h3>数据源状态</h3>
          <ul>
            <li v-for="item in statusItems" :key="item.label">
              <span>{{ item.label }}</span>
              <i :class="{ 'is-online': item.online }" />
            </li>
          </ul>
          <p>© 2024 VPP Platform</p>
        </div>
      </aside>

      <main class="market-content">
        <div class="market-toolbar">
          <div class="market-toolbar__title">市场概览</div>
          <div class="market-toolbar__controls">
            <label>
              <span>市场类型:</span>
              <select v-model="activeMarketType">
                <option v-for="item in marketTypes" :key="item" :value="item">
                  {{ item }}
                </option>
              </select>
            </label>
            <div class="market-toolbar__tabs">
              <button
                type="button"
                :class="{ 'is-active': activeMarketTab === '日前市场' }"
                @click="activeMarketTab = '日前市场'"
              >
                日前市场
              </button>
              <button
                type="button"
                :class="{ 'is-active': activeMarketTab === '实时市场' }"
                @click="activeMarketTab = '实时市场'"
              >
                实时市场
              </button>
            </div>
            <div class="market-toolbar__updated">
              数据更新时间：{{ lastUpdatedAt || (dashboardLoading ? '加载中' : '--') }}
            </div>
          </div>
        </div>

        <div class="market-overview-grid">
          <article
            v-for="card in statCards"
            :key="card.title"
            class="market-card market-metric-card"
            :class="`is-${card.tone}`"
          >
            <h3>{{ card.title }}</h3>
            <div class="market-metric-card__value">
              <strong>{{ card.value }}</strong>
              <span>{{ card.unit }}</span>
            </div>
            <div class="market-metric-card__subline">
              <span>{{ card.subLabel }}</span>
              <em>{{ card.delta }}</em>
            </div>

            <div v-if="'progress' in card" class="market-progress">
              <div class="market-progress__track">
                <i :style="{ width: `${card.progress}%` }" />
              </div>
              <span>{{ toNumber(card.progress).toFixed(2) }}%</span>
            </div>
            <div v-else class="market-sparkline">
              <span
                v-for="(value, index) in card.sparkline ?? []"
                :key="`${card.title}-${index}`"
                class="market-sparkline__dot"
                :style="{
                  left: `${((card.sparkline?.length ?? 1) <= 1 ? 0 : index / ((card.sparkline?.length ?? 1) - 1)) * 100}%`,
                  bottom: `${value * 56}px`
                }"
              />
            </div>
          </article>

          <article class="market-card market-info-card">
            <h3>市场信息</h3>
            <dl>
              <div><dt>市场名称</dt><dd>{{ marketSummary?.marketName ?? '--' }}</dd></div>
              <div><dt>结算周期</dt><dd>{{ marketSummary?.settlementCycle ?? '--' }}</dd></div>
              <div><dt>当前时段</dt><dd>{{ marketSummary?.currentTimeWindow ?? '--' }}</dd></div>
              <div><dt>当前阶段</dt><dd>{{ marketSummary?.currentPhase ?? '--' }}</dd></div>
              <div><dt>出清状态</dt><dd class="is-online">{{ marketSummary?.clearingStatus ?? '--' }}</dd></div>
            </dl>
          </article>
        </div>

        <div class="market-main-grid">
          <section class="market-card market-chart-card">
            <header class="market-section-header">
              <h3>电价曲线对比</h3>
              <div class="market-section-header__tabs">
                <button
                  v-for="tab in periodTabs"
                  :key="tab"
                  type="button"
                  :class="{ 'is-active': activePeriodTab === tab }"
                  @click="activePeriodTab = tab"
                >
                  {{ tab }}
                </button>
              </div>
            </header>
            <EChartPanel :option="trendChartOption" height="300px" />
          </section>

          <aside class="market-sidepanels">
            <section class="market-card market-distribution-card">
              <header class="market-section-header">
                <h3>市场价格分布(实时)</h3>
              </header>
              <div class="market-distribution-card__content">
                <EChartPanel :option="distributionChartOption" height="170px" />
                <ul class="market-distribution-card__legend">
                  <li v-for="item in distributionData" :key="item.name">
                    <span><i :style="{ backgroundColor: item.color }" />{{ item.name }}</span>
                    <strong>{{ item.value }}%</strong>
                  </li>
                </ul>
              </div>
            </section>

            <section class="market-card market-news-card">
              <header class="market-section-header">
                <h3>市场新闻</h3>
                <button type="button">更多</button>
              </header>
              <ul>
                <li v-for="item in marketNews" :key="item.title">
                  <time>{{ formatNewsTime(item.publishedAt) }}</time>
                  <span>{{ item.title }}</span>
                </li>
              </ul>
            </section>
          </aside>
        </div>

        <div class="market-bottom-grid" :style="bottomLayoutStyle">
          <section class="market-card market-table-card">
            <header class="market-section-header">
              <h3>分时电价表 <small>(元/kWh)</small></h3>
            </header>
            <div class="market-table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>时段</th>
                    <th>实时电价</th>
                    <th>日前电价</th>
                    <th>预测电价(今日)</th>
                    <th>预测电价(明日)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="row in tableRows" :key="row.period">
                    <td>{{ row.period }}</td>
                    <td :class="trendClass(row.realtime)">{{ formatNumber(row.realtime) }}</td>
                    <td>{{ formatNumber(row.dayAhead) }}</td>
                    <td class="is-warm">{{ formatNumber(row.forecastToday) }}</td>
                    <td class="is-purple">{{ formatNumber(row.forecastTomorrow) }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section class="market-card market-analysis-card">
            <header class="market-section-header">
              <h3>电价预测分析</h3>
            </header>
            <div class="market-analysis-card__tabs">
              <button
                v-for="tab in analysisTabs"
                :key="tab"
                type="button"
                :class="{ 'is-active': activeAnalysisTab === tab }"
                @click="activeAnalysisTab = tab"
              >
                {{ tab }}
              </button>
            </div>
            <EChartPanel :option="predictionChartOption" height="215px" />
            <div class="market-analysis-note">
              <h4>AI预测结论</h4>
              <p>{{ predictionConclusion }}</p>
            </div>
          </section>

          <section class="market-card market-recommend-card">
            <header class="market-section-header">
              <h3>智能调度建议</h3>
              <button type="button">更多</button>
            </header>
            <div class="market-recommend-card__list">
              <article
                v-for="item in recommendationCards"
                :key="item.title"
                class="market-recommend-item"
                :class="recommendationToneClass(item.tone)"
              >
                <div class="market-recommend-item__badge" aria-hidden="true" />
                <div class="market-recommend-item__content">
                  <h4>{{ item.title }}</h4>
                  <p>{{ item.description }}</p>
                  <strong>{{ item.valueLabel }}</strong>
                  <b>{{ item.value }}</b>
                </div>
              </article>
            </div>
          </section>
        </div>
      </main>
    </div>
  </section>
</template>

<style scoped>
.market-screen {
  min-height: 100vh;
  color: #e7f1ff;
  background:
    radial-gradient(circle at 50% 0%, rgba(23, 89, 235, 0.26), transparent 20%),
    linear-gradient(180deg, #020b1f 0%, #071736 18%, #08152f 100%);
}

.market-screen__topbar {
  display: grid;
  grid-template-columns: 276px minmax(0, 1fr) 318px;
  align-items: center;
  gap: 14px;
  height: 54px;
  padding: 0 14px;
  border-bottom: 1px solid rgba(58, 108, 185, 0.44);
  background: rgba(2, 11, 33, 0.92);
  box-shadow: inset 0 -1px 0 rgba(35, 118, 242, 0.18);
}

.market-brand {
  display: flex;
  align-items: center;
  gap: 12px;
}

.market-brand__logo {
  position: relative;
  width: 28px;
  height: 28px;
}

.market-brand__logo span {
  position: absolute;
  inset: 0;
  border: 2px solid rgba(245, 250, 255, 0.95);
  transform: rotate(45deg) scale(0.78);
}

.market-brand__logo span:nth-child(2) {
  transform: rotate(45deg) scale(0.54);
  opacity: 0.78;
}

.market-brand__logo span:nth-child(3) {
  transform: rotate(45deg) scale(0.3);
  opacity: 0.5;
}

.market-brand__title {
  font-size: 14px;
  font-weight: 700;
  letter-spacing: 0.04em;
  white-space: nowrap;
}

.market-primary-nav {
  display: flex;
  justify-content: center;
  gap: 6px;
}

.market-primary-nav__item {
  position: relative;
  min-width: 102px;
  height: 54px;
  padding: 0 16px;
  border: 0;
  color: #b6c9ef;
  background: transparent;
  cursor: pointer;
  font-size: 12px;
}

.market-primary-nav__item.is-active {
  color: #f7fbff;
  background:
    linear-gradient(135deg, rgba(21, 100, 255, 0.18), rgba(40, 133, 255, 0.3)),
    linear-gradient(180deg, rgba(18, 56, 145, 0.96), rgba(11, 36, 104, 0.96));
  clip-path: polygon(8% 0, 100% 0, 92% 100%, 0 100%);
  box-shadow: inset 0 -2px 0 rgba(72, 164, 255, 0.8), 0 0 18px rgba(39, 112, 255, 0.18);
}

.market-topbar__status {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 8px;
  min-width: 0;
  font-size: 11px;
}

.market-topbar__status > div {
  height: 32px;
  padding: 0 10px;
  border: 1px solid rgba(48, 83, 130, 0.72);
  border-radius: 6px;
  background: rgba(7, 20, 50, 0.92);
  display: inline-flex;
  align-items: center;
  white-space: nowrap;
}

.market-topbar__alarm {
  color: #ff705b;
}

.market-topbar__time {
  line-height: 1.1;
}

.market-screen__body {
  display: grid;
  grid-template-columns: 178px minmax(0, 1fr);
  gap: 10px;
  padding: 10px 8px 8px;
}

.market-sidebar {
  display: grid;
  gap: 12px;
}

.market-sidebar__menu,
.market-sidebar__status-card,
.market-card {
  border: 1px solid rgba(37, 86, 151, 0.72);
  border-radius: 6px;
  background:
    linear-gradient(180deg, rgba(9, 28, 66, 0.94), rgba(5, 18, 43, 0.96)),
    rgba(5, 18, 43, 0.96);
  box-shadow: inset 0 0 0 1px rgba(18, 54, 98, 0.4), 0 10px 30px rgba(0, 0, 0, 0.18);
}

.market-sidebar__menu {
  padding: 8px 0;
}

.market-sidebar__item {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 12px;
  height: 43px;
  padding: 0 18px;
  border: 0;
  color: #c8d6f1;
  background: transparent;
  text-align: left;
  cursor: pointer;
}

.market-sidebar__item.is-active {
  color: #ffffff;
  background: linear-gradient(90deg, rgba(22, 92, 222, 0.86), rgba(18, 70, 184, 0.86));
  box-shadow: inset 0 0 16px rgba(110, 190, 255, 0.18);
}

.market-sidebar__icon {
  width: 16px;
  height: 16px;
  border: 1px solid rgba(177, 200, 240, 0.85);
  border-radius: 4px;
  opacity: 0.9;
}

.market-sidebar__status-card {
  padding: 16px 14px 18px;
}

.market-sidebar__status-card h3 {
  margin: 0 0 14px;
  font-size: 14px;
}

.market-sidebar__status-card ul {
  display: grid;
  gap: 12px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.market-sidebar__status-card li {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  color: #b2c5e7;
  font-size: 13px;
}

.market-sidebar__status-card li i {
  width: 10px;
  height: 10px;
  margin-top: 4px;
  border-radius: 50%;
  background: #3a557e;
}

.market-sidebar__status-card li i.is-online {
  background: #2cd66f;
  box-shadow: 0 0 10px rgba(44, 214, 111, 0.45);
}

.market-sidebar__status-card p {
  margin: 40px 0 0;
  color: #6e84ab;
  font-size: 12px;
}

.market-content {
  display: grid;
  gap: 8px;
}

.market-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 0 8px;
  min-height: 40px;
}

.market-toolbar__title {
  font-size: 16px;
  font-weight: 700;
}

.market-toolbar__controls {
  display: flex;
  align-items: center;
  gap: 12px;
  color: #a7bbdd;
  font-size: 12px;
}

.market-toolbar__controls label {
  display: flex;
  align-items: center;
  gap: 8px;
}

.market-toolbar select {
  min-width: 112px;
  height: 30px;
  padding: 0 10px;
  border: 1px solid rgba(48, 83, 130, 0.72);
  border-radius: 6px;
  color: #f0f6ff;
  background: rgba(8, 25, 58, 0.92);
}

.market-toolbar__tabs,
.market-section-header__tabs,
.market-analysis-card__tabs {
  display: flex;
  gap: 6px;
}

.market-toolbar__tabs button,
.market-section-header__tabs button,
.market-analysis-card__tabs button,
.market-news-card button,
.market-recommend-card button {
  min-width: 74px;
  height: 30px;
  padding: 0 12px;
  border: 1px solid rgba(48, 83, 130, 0.72);
  border-radius: 6px;
  color: #b8caea;
  background: rgba(8, 25, 58, 0.82);
  cursor: pointer;
}

.market-toolbar__tabs button.is-active,
.market-section-header__tabs button.is-active,
.market-analysis-card__tabs button.is-active {
  color: #ffffff;
  border-color: rgba(70, 136, 255, 0.9);
  background: linear-gradient(180deg, #1b63df, #1350b8);
}

.market-overview-grid {
  display: grid;
  grid-template-columns: repeat(6, minmax(0, 1fr));
  gap: 8px;
}

.market-card {
  min-width: 0;
  padding: 12px 14px;
}

.market-metric-card {
  position: relative;
  min-height: 158px;
}

.market-metric-card h3,
.market-info-card h3,
.market-section-header h3,
.market-analysis-note h4,
.market-recommend-item h4 {
  margin: 0;
}

.market-metric-card__value {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-top: 14px;
}

.market-metric-card__value strong {
  font-size: 28px;
  font-weight: 700;
  line-height: 1;
}

.market-metric-card__value span {
  color: #c6d4eb;
}

.market-metric-card__subline {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 16px;
  color: #90a8cc;
  font-size: 12px;
}

.market-metric-card__subline em {
  font-style: normal;
  font-weight: 700;
}

.market-metric-card.is-green strong,
.market-metric-card.is-green em {
  color: #68ef7b;
}

.market-metric-card.is-orange strong,
.market-metric-card.is-orange em {
  color: #ffad39;
}

.market-metric-card.is-blue strong,
.market-metric-card.is-blue em {
  color: #4fa4ff;
}

.market-metric-card.is-purple strong,
.market-metric-card.is-purple em {
  color: #bf6fff;
}

.market-metric-card.is-cyan strong,
.market-metric-card.is-cyan em {
  color: #48dbff;
}

.market-sparkline {
  position: absolute;
  left: 14px;
  right: 14px;
  bottom: 16px;
  height: 46px;
  border-bottom: 1px solid rgba(62, 98, 152, 0.46);
}

.market-sparkline__dot {
  position: absolute;
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: currentColor;
  transform: translate(-50%, 50%);
}

.market-metric-card.is-green .market-sparkline,
.market-metric-card.is-green .market-sparkline__dot {
  color: #40dd63;
}

.market-metric-card.is-orange .market-sparkline,
.market-metric-card.is-orange .market-sparkline__dot {
  color: #ff9a24;
}

.market-metric-card.is-purple .market-sparkline,
.market-metric-card.is-purple .market-sparkline__dot {
  color: #b15eff;
}

.market-metric-card.is-cyan .market-sparkline,
.market-metric-card.is-cyan .market-sparkline__dot {
  color: #3dd6f7;
}

.market-progress {
  position: absolute;
  left: 14px;
  right: 14px;
  bottom: 16px;
  display: grid;
  gap: 8px;
}

.market-progress__track {
  height: 10px;
  overflow: hidden;
  border-radius: 999px;
  background: rgba(25, 49, 95, 0.92);
}

.market-progress__track i {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, #2f87ff, #46a0ff);
}

.market-progress span {
  display: block;
  text-align: right;
  color: #9cb2d5;
  font-size: 13px;
}

.market-info-card dl {
  display: grid;
  gap: 10px;
  margin: 16px 0 0;
}

.market-info-card dl div {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  font-size: 13px;
}

.market-info-card dt {
  color: #93a7cb;
}

.market-info-card dd {
  margin: 0;
}

.market-info-card dd.is-online {
  color: #4cde8f;
}

.market-main-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 280px;
  gap: 8px;
}

.market-chart-card {
  min-height: 334px;
}

.market-sidepanels {
  display: grid;
  gap: 8px;
}

.market-section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 8px;
}

.market-distribution-card__content {
  display: grid;
  align-items: center;
}

.market-distribution-card__legend {
  display: grid;
  gap: 8px;
  margin: -8px 0 0;
  padding: 0;
  list-style: none;
}

.market-distribution-card__legend li {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  font-size: 13px;
}

.market-distribution-card__legend span {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #bac8e0;
}

.market-distribution-card__legend span i {
  width: 9px;
  height: 9px;
  border-radius: 50%;
}

.market-news-card ul {
  display: grid;
  gap: 10px;
  margin: 8px 0 0;
  padding: 0;
  list-style: none;
}

.market-news-card li {
  display: grid;
  grid-template-columns: 74px 1fr;
  gap: 10px;
  font-size: 12px;
}

.market-news-card time {
  color: #9ab0d2;
}

.market-news-card span {
  color: #dce7f7;
  line-height: 1.45;
}

.market-bottom-grid {
  gap: 8px;
}

.market-table-wrap {
  max-height: 340px;
  overflow: auto;
}

.market-table-card {
  flex: 0 0 35%;
}

.market-analysis-card {
  flex: 0 0 29%;
}

.market-recommend-card {
  flex: 1 1 auto;
}

.market-table-wrap table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.market-table-wrap th,
.market-table-wrap td {
  padding: 12px 10px;
  text-align: left;
  border-bottom: 1px solid rgba(41, 71, 118, 0.48);
}

.market-table-wrap thead th {
  position: sticky;
  top: 0;
  z-index: 1;
  color: #aecaef;
  background: rgba(9, 25, 59, 0.96);
}

.market-table-wrap td.is-cool {
  color: #69e57d;
}

.market-table-wrap td.is-warm {
  color: #ff8165;
}

.market-table-wrap td.is-hot {
  color: #ff6c52;
}

.market-table-wrap td.is-purple {
  color: #af7eff;
}

.market-analysis-card__tabs {
  margin-bottom: 10px;
}

.market-analysis-note {
  margin-top: 6px;
  padding: 12px 14px;
  border: 1px solid rgba(42, 79, 132, 0.56);
  border-radius: 8px;
  background: rgba(8, 25, 58, 0.82);
}

.market-analysis-note h4 {
  color: #66bbff;
  font-size: 15px;
}

.market-analysis-note p {
  margin: 10px 0 0;
  color: #d7e6fb;
  line-height: 1.7;
  font-size: 13px;
}

.market-recommend-card__list {
  display: grid;
  gap: 10px;
}

.market-recommend-item {
  display: grid;
  grid-template-columns: 44px 1fr;
  gap: 14px;
  padding: 14px 18px;
  border: 1px solid rgba(39, 74, 126, 0.56);
  border-radius: 8px;
  background: rgba(9, 25, 59, 0.74);
}

.market-recommend-item__badge {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.04);
}

.market-recommend-item.is-green .market-recommend-item__badge {
  box-shadow: inset 0 0 0 1px rgba(88, 236, 122, 0.36);
  background: radial-gradient(circle at 40% 40%, rgba(88, 236, 122, 0.28), rgba(88, 236, 122, 0.06));
}

.market-recommend-item.is-orange .market-recommend-item__badge {
  box-shadow: inset 0 0 0 1px rgba(255, 160, 61, 0.36);
  background: radial-gradient(circle at 40% 40%, rgba(255, 160, 61, 0.28), rgba(255, 160, 61, 0.06));
}

.market-recommend-item.is-blue .market-recommend-item__badge {
  box-shadow: inset 0 0 0 1px rgba(67, 149, 255, 0.36);
  background: radial-gradient(circle at 40% 40%, rgba(67, 149, 255, 0.28), rgba(67, 149, 255, 0.06));
}

.market-recommend-item__content p,
.market-recommend-item__content strong,
.market-recommend-item__content b {
  display: block;
}

.market-recommend-item__content h4 {
  font-size: 15px;
}

.market-recommend-item__content p {
  margin: 6px 0 4px;
  color: #b6c9ea;
  font-size: 12px;
}

.market-recommend-item__content strong {
  color: #93a9cd;
  font-size: 12px;
  font-weight: 500;
}

.market-recommend-item__content b {
  margin-top: 4px;
  font-size: 16px;
}

.market-recommend-item.is-green h4,
.market-recommend-item.is-green b {
  color: #64eb8a;
}

.market-recommend-item.is-orange h4,
.market-recommend-item.is-orange b {
  color: #ffa142;
}

.market-recommend-item.is-blue h4,
.market-recommend-item.is-blue b {
  color: #53a6ff;
}

@media (max-width: 1440px) {
  .market-screen__topbar {
    grid-template-columns: 250px minmax(0, 1fr) 260px;
  }

  .market-overview-grid {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (max-width: 1280px) {
  .market-screen__body {
    grid-template-columns: 1fr;
  }

  .market-sidebar {
    grid-template-columns: minmax(0, 1fr) 320px;
  }

  .market-main-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 960px) {
  .market-screen__topbar,
  .market-toolbar,
  .market-section-header {
    grid-template-columns: 1fr;
    display: grid;
    height: auto;
  }

  .market-primary-nav,
  .market-topbar__status,
  .market-toolbar__controls {
    justify-content: flex-start;
    flex-wrap: wrap;
  }

  .market-sidebar {
    grid-template-columns: 1fr;
  }

  .market-overview-grid {
    grid-template-columns: 1fr;
  }

  .market-sidebar__item {
    height: 40px;
  }
}
</style>
