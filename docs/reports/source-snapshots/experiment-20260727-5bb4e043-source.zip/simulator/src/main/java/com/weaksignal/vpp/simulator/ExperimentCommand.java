package com.weaksignal.vpp.simulator;

import java.util.List;
import java.util.Map;

/**
 * 实验命令。
 *
 * @param commandType 命令类型
 * @param experimentScenarioCode 实验场景编码
 * @param experimentRunId 实验运行标识
 * @param scenario 关联演示场景
 * @param targetStationIds 目标场站
 * @param faultParameters 故障参数
 * @param severityLevel 严重等级
 * @param durationSeconds 持续时间
 * @param automaticRecovery 是否自动恢复
 */
public record ExperimentCommand(
        String commandType,
        String experimentScenarioCode,
        String experimentRunId,
        DemoScenario scenario,
        List<String> targetStationIds,
        Map<String, Double> faultParameters,
        int severityLevel,
        int durationSeconds,
        boolean automaticRecovery
) {
}
